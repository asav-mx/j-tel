# Auditoría · UI de la app ¿Ontoy?

Fuente: repo `asav-mx/j-tel` · `apps/publico` (leído 2026-09-24) + reglas de `CLAUDE.md` y `readme.md`.
Estructura real: la app **abre en la ciudad** (no en una ruta). Barra fija: **Inicio · Mapa · Ir a · Pase**.

## 1. Pantallas
| # | Pantalla | Archivos del repo | Qué resuelve |
|---|---|---|---|
| 1 | Inicio | vista-inicio, rutas-de-inicio, atajo-de-parada, tira-de-rutas, cabeza-de-ruta | Tus paradas guardadas arriba; rutas de la ciudad con su estado (abierta / cerrada, abre a las… / por arrancar) |
| 2 | Mapa | vista-mapa, panel-de-rutas, hoja-de-parada, pista-del-mapa, tinte-* | Rutas en su color, Cami en vivo, Tino en cada parada, «Tú estás aquí» (pasajero 12a); hoja inferior de la parada con llegadas |
| 3 | Ir a | vista-ira, buscar-lugar, rutas-cerca | Buscar un lugar → qué ruta, dónde subirte, cuánto caminas, cuándo pasa |
| 4 | Paradas | vista-paradas, paradas-guardadas, favoritas | Guardar / quitar paradas, sin cuenta (se quedan en el teléfono) |
| 5 | Avisos | vista-avisos, avisos, avisos-vistos, avisos-del-telefono | Desvíos y horarios con fecha y «según la concesión»; permiso de notificaciones |
| 6 | Pase | vista-pase, codigo-qr, pase-del-telefono, banda-rd | Pase QR del pasajero (R&D, lleva banda) |
| 7 | Lector `/validador` | validador/lector | Lector del camión (R&D, operación) |
| 8 | 404 · Privacidad | not-found, privacidad | Callejón sin salida amable · textos legales |

## 2. Estados que cada pantalla necesita
- **Sin dato** (decir-el-no): Ontoy lo dice, nunca adivina. Placa sin minutos.
- **Dato viejo**: «posición de hace N s» (ritmo-del-sondeo).
- **Ruta cerrada** («abre a las 5:30») · **por arrancar** («arranca el 1 de oct») · **de noche**: Ontoy con los ojos cerrados.
- **Sin red / offline** (service worker) · **cargando**.
- **Ubicación**: pedir, denegada, imprecisa.
- **Vacíos**: sin paradas guardadas, sin avisos, búsqueda sin resultados.
- **Modo noche** (tema.ts) y **reduced-motion** (solo cambia la cara).

## 3. Componentes base
Barra (ícono + palabra, activo con pastilla y trazo) · Placa de ruta (carbón; «¡ya!» en color de ruta) · Tarjeta de llegada · Hoja inferior (mapa) · Buscador + resultados · Chips de ruta · Tira de rutas · Aviso (fecha + fuente) · Botón de guardar parada · QR del pase · Ontoy en sus reacciones ligadas a dato real.

## 4. Flujos a diseñar de punta a punta
1. Primera vez: abrir → permiso de ubicación → paradas cercanas.
2. Guardar mi parada → al volver, Inicio ya dice cuándo pasa.
3. «Voy a…» → ruta → caminar a la parada → ¡ya viene!
4. Llega un aviso de desvío → leerlo → ver la parada alterna en el mapa.
5. De noche / sin servicio → qué dice Ontoy y cuándo vuelve.
6. Pase: mostrar QR al subir (R&D).

## 5. Decisiones (2026-09-24)
- Lector: la cara que ve quien sube **lleva el universo**; el lado del operador, sin caritas.
- El Pase (R&D) **entra**.
- Sin pantallas de bienvenida: una sola tarjeta de Ontoy en Inicio; el QR de un Tino abre esa parada.
- Tótem central en el mapa cuando comparten parada 2 o más rutas.
- Estándar completo en `Estandar de pantallas.md`.

## 6. Orden sugerido
Componentes base → Inicio → Mapa + hoja de parada → Ir a → Avisos → estados transversales → Pase.
