---
name: ontoy-design
description: Use this skill to generate well-branded interfaces and assets for ¿Ontoy? (passenger transit app), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, characters and rules.
user-invocable: true
---

Read the readme.md file within this skill, and CLAUDE.md for the approved rules, then explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.
Always use colors from tokens/colors.css — never invent hex values. Orange is only for Ontoy. Route colors come from data.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
